import axios from "axios";

const api = axios.create({
    baseURL: "http://localhost:5000/api", // Your backend API URL
    headers: {
        "Content-Type": "application/json",
    },
});

// You can add any specific configurations or interceptors here
api.interceptors.request.use(
    (config) => {
        // You can add auth tokens or other configurations if needed
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export default api;
