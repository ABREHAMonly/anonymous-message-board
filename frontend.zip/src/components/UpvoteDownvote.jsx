import { useState } from "react";
import axios from "../utils/api";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa";

const UpvoteDownvote = ({ messageId, initialUpvotes, initialDownvotes }) => {
    const [upvotes, setUpvotes] = useState(initialUpvotes);
    const [downvotes, setDownvotes] = useState(initialDownvotes);

    const handleVote = async (type) => {
        try {
            await axios.patch(`/messages/${messageId}/vote`, { vote: type });
            if (type === "upvote") setUpvotes(upvotes + 1);
            if (type === "downvote") setDownvotes(downvotes + 1);
        } catch (err) {
            console.error("Voting failed", err);
        }
    };

    return (
        <div style={styles.container}>
            <button onClick={() => handleVote("upvote")} style={styles.upvote}>
                <FaThumbsUp /> {upvotes}
            </button>
            <button onClick={() => handleVote("downvote")} style={styles.downvote}>
                <FaThumbsDown /> {downvotes}
            </button>
        </div>
    );
};

const styles = {
    container: {
        display: "flex",
        alignItems: "center",
        gap: "12px",
    },
    upvote: {
        backgroundColor: "#28a745",
        color: "white",
        padding: "8px 12px",
        borderRadius: "6px",
        border: "none",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "6px",
        transition: "background-color 0.3s ease-in-out",
    },
    downvote: {
        backgroundColor: "#dc3545",
        color: "white",
        padding: "8px 12px",
        borderRadius: "6px",
        border: "none",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "6px",
        transition: "background-color 0.3s ease-in-out",
    }
};

export default UpvoteDownvote;