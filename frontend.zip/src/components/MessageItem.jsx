import { useState } from "react";
import axios from "../utils/api";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa";

const MessageItem = ({ message }) => {
    const [upvotes, setUpvotes] = useState(message.upvotes);
    const [downvotes, setDownvotes] = useState(message.downvotes);

    const handleVote = async (type) => {
        try {
            await axios.patch(`/messages/${message._id}/vote`, { vote: type });
            if (type === "upvote") setUpvotes(upvotes + 1);
            if (type === "downvote") setDownvotes(downvotes + 1);
        } catch (err) {
            console.error("Voting failed", err);
        }
    };

    return (
        <div style={styles.container}>
            <p style={styles.messageText}>{message.text}</p>
            <small style={styles.info}>Category: {message.category} | By: {message.user}</small>
            <div style={styles.actions}>
                <button onClick={() => handleVote("upvote")} style={styles.upvote}>
                    <FaThumbsUp /> {upvotes}
                </button>
                <button onClick={() => handleVote("downvote")} style={styles.downvote}>
                    <FaThumbsDown /> {downvotes}
                </button>
            </div>
        </div>
    );
};

const styles = {
    container: {
        padding: "15px",
        backgroundColor: "#f9f9f9",
        borderRadius: "10px",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        marginBottom: "10px",
        transition: "transform 0.2s ease-in-out",
    },
    messageText: {
        fontSize: "18px",
        color: "#333",
        marginBottom: "5px",
    },
    info: {
        fontSize: "14px",
        color: "#777",
    },
    actions: {
        marginTop: "10px",
        display: "flex",
        gap: "10px",
        alignItems: "center",
    },
    upvote: {
        backgroundColor: "#28a745",
        color: "white",
        padding: "8px 12px",
        borderRadius: "5px",
        border: "none",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "5px",
        transition: "background-color 0.3s ease-in-out",
    },
    downvote: {
        backgroundColor: "#dc3545",
        color: "white",
        padding: "8px 12px",
        borderRadius: "5px",
        border: "none",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "5px",
        transition: "background-color 0.3s ease-in-out",
    }
};

export default MessageItem;