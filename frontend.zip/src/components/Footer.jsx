const Footer = () => {
    return (
        <footer style={styles.footer}>
            <p style={styles.text}>
                © {new Date().getFullYear()} Anonymous Message Board. All rights reserved.
            </p>
        </footer>
    );
};

const styles = {
    footer: {
        backgroundColor: "#333",
        color: "white",
        padding: "20px 0",
        marginTop: "40px",
        textAlign: "center",
        boxShadow: "0 -4px 6px rgba(0, 0, 0, 0.1)",
        transition: "background-color 0.3s ease-in-out",
    },
    text: {
        fontSize: "16px",
        opacity: "0.8",
        transition: "opacity 0.3s ease-in-out",
    }
};

export default Footer;