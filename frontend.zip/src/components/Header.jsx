import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import AdminPage from "../pages/AdminPage";

const Header = () => {
    const [isVisible, setIsVisible] = useState(true);
    const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const lastScrollY = useRef(0);
    const navigate = useNavigate();

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > lastScrollY.current) {
                setIsVisible(false);
            } else {
                setIsVisible(true);
            }
            lastScrollY.current = window.scrollY;
        };

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <>
            <header
                style={{
                    ...styles.header,
                    transform: isVisible ? "translateY(0)" : "translateY(-100%)"
                }}
            >
                <div style={styles.container}>
                    {/* Logo */}
                    <div style={styles.logoContainer} onClick={() => navigate("/")}>
                        <span style={styles.logo}>🕵️‍♂️</span>
                        <span style={styles.logoText}>Anonymus Board</span>
                    </div>

                    {/* Navigation - Always Visible on Large Screens, Collapsible on Mobile */}
                    <nav style={{ 
                        ...styles.nav, 
                        ...(isMobileMenuOpen ? styles.navMobileOpen : styles.navMobileClosed) 
                    }}>
                        <button style={styles.navLink} onClick={() => navigate("/")}>Home</button>
                        <button style={styles.navLink} onClick={() => navigate("/categories")}>Categories</button>
                        <button style={styles.navLink} onClick={() => setIsAdminModalOpen(true)}>Admin</button>
                    </nav>

                    {/* Hamburger Menu (Visible on Small Screens) */}
                    <div 
                        style={{ 
                            ...styles.hamburger, 
                            display: isMobileMenuOpen ? "none" : "flex" 
                        }} 
                        onClick={() => setIsMobileMenuOpen(true)}
                    >
                        <div style={styles.bar}></div>
                        <div style={styles.bar}></div>
                        <div style={styles.bar}></div>
                    </div>

                    {/* Close Button inside Mobile Menu */}
                    {isMobileMenuOpen && (
                        <button 
                            style={styles.closeMenuButton} 
                            onClick={() => setIsMobileMenuOpen(false)}
                        >
                            ✖
                        </button>
                    )}
                </div>
            </header>

            {/* Admin Modal */}
            {isAdminModalOpen && (
                <div style={styles.modalOverlay} onClick={() => setIsAdminModalOpen(false)}>
                    <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
                        <AdminPage />
                        <button style={styles.closeButton} onClick={() => setIsAdminModalOpen(false)}>Close</button>
                    </div>
                </div>
            )}
        </>
    );
};

// Embedded CSS Styles
const styles = {
    header: {
        background: "linear-gradient(135deg, #007bff, #6610f2)",
        color: "white",
        padding: "15px 0",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
        position: "fixed",
        width: "100%",
        top: 0,
        zIndex: 1000,
        transition: "transform 0.3s ease-in-out",
    },
    container: {
        maxWidth: "1100px",
        margin: "0 auto",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 20px",
        position: "relative",
    },
    logoContainer: {
        display: "flex",
        alignItems: "center",
        gap: "10px",
        cursor: "pointer",
    },
    logo: {
        fontSize: "28px",
    },
    logoText: {
        fontSize: "24px",
        fontWeight: "bold",
    },
    /* Large Screens - Always Visible */
    nav: {
        display: "flex",
        gap: "15px",
    },
    /* Mobile - Hidden Menu (Default) */
    navMobileClosed: {
        display: "none",
        flexDirection: "column",
        position: "absolute",
        top: "60px",
        right: 0,
        background: "rgba(0, 0, 0, 0.9)",
        width: "200px",
        padding: "10px",
        borderRadius: "5px",
        zIndex: 2000,
        transition: "transform 0.3s ease-in-out",
    },
    /* Mobile - Open Menu */
    navMobileOpen: {
        display: "flex",
        flexDirection: "column",
        position: "absolute",
        top: "60px",
        right: 0,
        background: "rgba(0, 0, 0, 0.9)",
        width: "200px",
        padding: "10px",
        borderRadius: "5px",
        zIndex: 2000,
    },
    navLink: {
        background: "none",
        border: "none",
        color: "white",
        fontSize: "18px",
        cursor: "pointer",
        padding: "10px",
        textAlign: "left",
    },
    /* Hamburger Menu */
    hamburger: {
        display: "none",
        flexDirection: "column",
        gap: "5px",
        cursor: "pointer",
    },
    bar: {
        width: "30px",
        height: "3px",
        background: "white",
        transition: "0.3s",
    },
    /* Close Button for Mobile Menu */
    closeMenuButton: {
        position: "absolute",
        top: "15px",
        right: "20px",
        background: "none",
        border: "none",
        color: "white",
        fontSize: "24px",
        cursor: "pointer",
    },
    modalOverlay: {
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 2000,
    },
    modalContent: {
        background: "white",
        padding: "20px",
        borderRadius: "8px",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
        textAlign: "center",
    },
    closeButton: {
        marginTop: "10px",
        padding: "10px 20px",
        border: "none",
        background: "#007bff",
        color: "white",
        borderRadius: "5px",
        cursor: "pointer",
    }
};

/* Apply responsive styles dynamically */
if (window.innerWidth <= 768) {
    styles.nav.display = "none"; // Hide nav by default on mobile
    styles.hamburger.display = "flex"; // Show hamburger icon on mobile
}

export default Header;
