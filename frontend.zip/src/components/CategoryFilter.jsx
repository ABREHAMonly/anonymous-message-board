import { useState, useEffect } from "react";
import axios from "../utils/api";  // axios setup
import { FaFunnelDollar } from 'react-icons/fa'; // Using a funnel filter icon

const CategoryFilter = ({ onSelectCategory }) => {
    const [categories, setCategories] = useState([]);
    const [showModal, setShowModal] = useState(false);  // Track modal visibility
    const [selectedCategory, setSelectedCategory] = useState('');  // Track selected category

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get("/categories");
                setCategories(response.data);
            } catch (err) {
                console.error("Error fetching categories", err);
            }
        };

        fetchCategories();
    }, []);

    const handleFilterClick = () => {
        setShowModal(!showModal);  // Toggle the modal visibility
    };

    const handleCategorySelect = (category) => {
        setSelectedCategory(category);  // Set the selected category
        onSelectCategory(category);  // Call the function to apply the filter
        setShowModal(false);  // Close modal after category selection
    };

    return (
        <div style={styles.container}>
            <div style={styles.iconWrapper} onClick={handleFilterClick}>
                <FaFunnelDollar size={24} style={styles.icon} />
                <span style={styles.selectedCategoryText}>
                    {selectedCategory || "Filter by Category"}
                </span>
            </div>

            {showModal && (
                <div style={styles.modal}>
                    <div style={styles.modalContent}>
                        <h3 style={styles.modalTitle}>Select Category</h3>
                        <div style={styles.categoryList}>
                            <div style={styles.categoryItem} onClick={() => handleCategorySelect('')}>
                                <p>All Categories</p>
                            </div>
                            {categories.map((cat) => (
                                <div
                                    key={cat._id}
                                    style={styles.categoryItem}
                                    onClick={() => handleCategorySelect(cat.name)}
                                >
                                    <p>{cat.name}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const styles = {
    container: {
        position: 'absolute',
        right: '15px',
        marginTop: "0px",
        marginBottom: "16px",
        padding: "10px",
        backgroundColor: "#f9f9f9",
        borderRadius: "8px",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
    },
    iconWrapper: {
        display: "flex",
        alignItems: "center",  // Align text and icon
        justifyContent: "center",
        cursor: "pointer",
        transition: "transform 0.3s ease",
        width: "100%",
        maxWidth: "300px",
    },
    icon: {
        color: "#555",
        marginRight: "10px",
    },
    selectedCategoryText: {
        fontSize: "16px",
        color: "#555",
        fontWeight: "bold",
        transition: "color 0.3s ease",
    },
    modal: {
        position: "fixed",
        top: "0",
        left: "0",
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: "1000",
    },
    modalContent: {
        backgroundColor: "white",
        borderRadius: "8px",
        padding: "20px",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        width: "90%",
        maxWidth: "400px",
    },
    modalTitle: {
        fontSize: "20px",
        fontWeight: "bold",
        marginBottom: "16px",
        textAlign: "center",
    },
    categoryList: {
        display: "flex",
        flexDirection: "column",
        gap: "10px",
    },
    categoryItem: {
        padding: "12px",
        backgroundColor: "#f1f1f1",
        borderRadius: "6px",
        cursor: "pointer",
        transition: "background-color 0.3s",
        textAlign: "center",
    },
    categoryItemHover: {
        backgroundColor: "#2196F3",
        color: "white",
    },
    "@media (max-width: 600px)": {
        container: {
            padding: "8px",
        },
        modalContent: {
            width: "95%",
        },
        iconWrapper: {
            justifyContent: "space-between",
        },
        selectedCategoryText: {
            fontSize: "14px",
        },
    }
};

export default CategoryFilter;
