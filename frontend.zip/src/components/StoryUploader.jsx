import { useState } from "react";
import { CloudUpload } from "lucide-react";
import axios from "../utils/api";

const StoryUploader = ({ onUpload }) => {
    const [text, setText] = useState("");
    const [image, setImage] = useState(null);
    const [dragOver, setDragOver] = useState(false);

    const handleImageChange = (e) => {
        setImage(e.target.files[0]);
    };

    const handleDragOver = (e) => {
        e.preventDefault();
        setDragOver(true);
    };

    const handleDragLeave = () => {
        setDragOver(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setDragOver(false);
        setImage(e.dataTransfer.files[0]);
    };

    const handleUpload = async () => {
        try {
            const formData = new FormData();
            formData.append("text", text);
            if (image) {
                formData.append("image", image);
            }

            const response = await axios.post("/stories/upload", formData, {
                headers: { "Content-Type": "multipart/form-data" },
            });

            setText("");
            setImage(null);
            alert("Story uploaded successfully!");

            if (response.data && response.data.story) {
                onUpload(response.data.story);
            }
        } catch (err) {
            alert("Error uploading story");
        }
    };

    return (
        <div style={styles.container}>
            <div
                style={{ ...styles.dropZone, borderColor: dragOver ? "#007bff" : "#ccc" }}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
            >
                <CloudUpload size={50} color={dragOver ? "#007bff" : "#555"} />
                <p>{image ? image.name : "Drag & Drop an image or Click to Upload"}</p>
                <input type="file" onChange={handleImageChange} style={styles.fileInput} />
            </div>
            <textarea
                placeholder="Write your story..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                style={styles.textarea}
            />
            <button onClick={handleUpload} style={styles.button}>Upload Story</button>
        </div>
    );
};

const styles = {
    container: {
        display: "flex",
        flexDirection: "column",
        padding: "20px",
        backgroundColor: "#fff",
        borderRadius: "8px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        width: "350px",
        alignItems: "center",
    },
    dropZone: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        border: "2px dashed #ccc",
        borderRadius: "8px",
        padding: "20px",
        width: "100%",
        cursor: "pointer",
        position: "relative",
    },
    fileInput: {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        opacity: 0,
        cursor: "pointer",
    },
    textarea: {
        padding: "10px",
        marginTop: "10px",
        fontSize: "14px",
        borderRadius: "6px",
        border: "1px solid #ddd",
        height: "80px",
        width: "100%",
    },
    button: {
        padding: "10px",
        backgroundColor: "#2196F3",
        color: "#fff",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
        width: "100%",
        marginTop: "10px",
    },
};

export default StoryUploader;
