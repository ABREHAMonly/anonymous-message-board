import { useEffect, useState } from "react";
import axios from "../utils/api";
import { FaThumbsUp, FaThumbsDown, FaHeart } from "react-icons/fa";
import Modal from "react-modal";

const StoryViewer = ({ onNewStoryUpload }) => {
    const [stories, setStories] = useState([]);
    const [loading, setLoading] = useState(true);  // New state for loading
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [currentStory, setCurrentStory] = useState(null);
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const fetchStories = async () => {
            try {
                const response = await axios.get("/stories/all");
                setStories(response.data);
                setLoading(false);  // Set loading to false after data is fetched
            } catch (err) {
                console.error("Error fetching stories", err);
                setLoading(false);
            }
        };

        fetchStories();
    }, []);

    useEffect(() => {
        if (onNewStoryUpload) {
            setStories((prevStories) => [onNewStoryUpload, ...prevStories]);
        }
    }, [onNewStoryUpload]);

    const handleReaction = async (storyId, reactionType) => {
        try {
            await axios.post("/stories/reaction", { storyId, reactionType });

            setStories((prevStories) =>
                prevStories.map((story) => {
                    if (story._id === storyId) {
                        return {
                            ...story,
                            reactions: {
                                ...story.reactions,
                                [reactionType]: story.reactions[reactionType] + 1,
                            },
                        };
                    }
                    return story;
                })
            );
        } catch (err) {
            alert("Error adding reaction");
        }
    };

    const openModal = (index) => {
        setCurrentIndex(index);
        setCurrentStory(stories[index]);
        setModalIsOpen(true);
    };

    const closeModal = () => {
        setModalIsOpen(false);
        setCurrentStory(null);
    };

    const nextStory = () => {
        if (currentIndex < stories.length - 1) {
            setCurrentIndex(currentIndex + 1);
            setCurrentStory(stories[currentIndex + 1]);
        }
    };

    const prevStory = () => {
        if (currentIndex > 0) {
            setCurrentIndex(currentIndex - 1);
            setCurrentStory(stories[currentIndex - 1]);
        }
    };

    const truncateText = (text, maxLength = 100) => {
        return text.length > maxLength ? text.slice(0, maxLength) + "...more" : text;
    };

    // Skeleton Loader Component
    const SkeletonLoader = () => (
        <div style={styles.skeletonWrapper}>
            <div style={styles.skeletonStory}></div>
            <div style={styles.skeletonStory}></div>
            <div style={styles.skeletonStory}></div>
        </div>
    );

    return (
        <div style={styles.container}>
            <div style={styles.storyWrapper}>
                {loading ? (
                    <SkeletonLoader />
                ) : (
                    stories.map((story, index) => (
                        <div key={story._id} style={styles.story} onClick={() => openModal(index)}>
                            <p>{truncateText(story.text)}</p>
                            {story.imageUrl && (
                                <img
                                    src={`http://localhost:5000${story.imageUrl}`}
                                    alt="Story"
                                    style={styles.image}
                                />
                            )}
                            <div style={styles.timestamp}>
                                <small>{new Date(story.timestamp).toLocaleString()}</small>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {modalIsOpen && currentStory && (
                <Modal isOpen={modalIsOpen} onRequestClose={closeModal} style={styles.modal}>
                    <div style={styles.modalContent}>
                        <button onClick={closeModal} style={styles.closeButton}>X</button>
                        <div style={styles.mediaContainer}>
                            {currentStory.imageUrl && (
                                <img
                                    src={`http://localhost:5000${currentStory.imageUrl}`}
                                    alt="Story"
                                    style={styles.modalImage}
                                />
                            )}
                        </div>
                        <p style={styles.modalText}>{currentStory.text}</p>
                        <div style={styles.reactions}>
                            <FaThumbsUp
                                onClick={() => handleReaction(currentStory._id, "true")}
                                style={styles.icon}
                            />
                            {currentStory.reactions.true}
                            <FaThumbsDown
                                onClick={() => handleReaction(currentStory._id, "false")}
                                style={styles.icon}
                            />
                            {currentStory.reactions.false}
                            <FaHeart
                                onClick={() => handleReaction(currentStory._id, "love")}
                                style={styles.icon}
                            />
                            {currentStory.reactions.love}
                        </div>
                        <div style={styles.navigationButtons}>
                            <button
                                onClick={prevStory}
                                disabled={currentIndex === 0}
                                style={styles.navButton}
                            >
                                ⟨
                            </button>
                            <button
                                onClick={nextStory}
                                disabled={currentIndex === stories.length - 1}
                                style={styles.navButton}
                            >
                                ⟩
                            </button>
                        </div>
                    </div>
                </Modal>
            )}
        </div>
    );
};

const styles = {
    container: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100%",
        padding: "20px",
    },
    storyWrapper: {
        display: "flex",
        gap: "15px",
        padding: "10px",
        height: "200px",
    },
    story: {
        width: "150px",
        background: "#fff",
        borderRadius: "10px",
        padding: "10px",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
        flexShrink: 0,
        textAlign: "center",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        height: "190px",
    },
    image: {
        width: "100%",
        height: "auto",
        maxHeight: "120px",
        objectFit: "cover",
        borderRadius: "8px",
        marginTop: "10px",
    },
    timestamp: {
        marginTop: "0px",
        fontSize: "12px",
        color: "rgba(44, 43, 43, 0.9)",
    },
    modal: {
        overlay: { backgroundColor: "rgba(0, 0, 0, 0.9)", zIndex: 1000, top: "0" },
        content: { padding: "0", border: "none", background: "none", maxWidth: "100%", maxHeight: "100%" },
    },
    modalContent: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: "100%",
        position: "relative",
        color: "#fff",
    },
    closeButton: { position: "absolute", top: "10px", right: "10px", padding: "10px", backgroundColor: "#ff4d4d", color: "#fff", border: "none", borderRadius: "50%", cursor: "pointer" },
    mediaContainer: { display: "flex", justifyContent: "center", alignItems: "center", width: "100%", height: "70%" },
    modalImage: { width: "50%", height: "auto", objectFit: "contain", borderRadius: "10px" },
    modalText: { margin: "15px 0", fontSize: "20px", background: "black", color: "#fff", textAlign: "center", maxWidth: "80%", wordBreak: "break-word" },
    reactions: {
        display: "flex",
        justifyContent: "center",
        gap: "20px",
        fontSize: "30px",
        marginTop: "15px",
        background: "black",
        zIndex: "10",
        position: "relative",
    },
    icon: {
        cursor: "pointer",
        zIndex: "10",
    },
    navigationButtons: {
        display: "flex",
        justifyContent: "space-between",
        width: "100%",
        position: "absolute",
        bottom: "20px",
    },
    navButton: {
        padding: "15px",
        fontSize: "24px",
        backgroundColor: "#2196F3",
        color: "#fff",
        border: "none",
        borderRadius: "50%",
        cursor: "pointer",
        transition: "background 0.3s",
    },
    skeletonWrapper: {
        display: "flex",
        gap: "15px",
        flexDirection: "column",
    },
    skeletonStory: {
        width: "150px",
        height: "100px",
        backgroundColor: "#e0e0e0",
        borderRadius: "10px",
    },
};

export default StoryViewer;
