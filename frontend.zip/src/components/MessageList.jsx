import { useEffect, useState } from "react";
import axios from "../utils/api";
import MessageItem from "./MessageItem";

const MessageList = () => {
    const [messages, setMessages] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchMessages = async () => {
            try {
                const response = await axios.get("/messages");
                setMessages(response.data);
            } catch (err) {
                console.error("Error fetching messages", err);
            } finally {
                setLoading(false);
            }
        };

        fetchMessages();
    }, []);

    if (loading) {
        return (
            <div style={styles.container}>
                {[...Array(5)].map((_, index) => (
                    <div key={index} style={styles.skeleton}></div>
                ))}
            </div>
        );
    }

    return (
        <div style={styles.container}>
            {messages.length > 0 ? (
                messages.map((msg) => <MessageItem key={msg._id} message={msg} />)
            ) : (
                <p style={styles.noMessages}>No messages yet.</p>
            )}
        </div>
    );
};

const styles = {
    container: {
        marginTop: "16px",
        padding: "20px",
        backgroundColor: "#ffffff",
        borderRadius: "12px",
        boxShadow: "0 6px 12px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease-in-out",
        maxWidth: "100%",
        margin: "0 auto",
    },
    skeleton: {
        backgroundColor: "#e0e0e0",
        borderRadius: "8px",
        height: "50px",
        marginBottom: "15px",
        animation: "pulse 1.5s infinite ease-in-out",
    },
    loading: {
        fontSize: "16px",
        fontWeight: "bold",
        color: "#555",
        textAlign: "center",
    },
    noMessages: {
        fontSize: "16px",
        fontWeight: "bold",
        color: "#888",
        textAlign: "center",
    },
    // Media Queries for Responsiveness
    "@media (max-width: 768px)": {
        container: {
            padding: "15px",
        },
    },
    "@media (max-width: 480px)": {
        container: {
            padding: "10px",
        },
    },
};

export default MessageList;
