import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function AdminDashboard() {
  const [messages, setMessages] = useState([]);
  const [filteredMessages, setFilteredMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      if (!token) {
        navigate('/admin');
        return;
      }

      const response = await fetch('http://localhost:5000/api/messages', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setMessages(data);
      setFilteredMessages(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteMessage = async (id) => {
    try {
      const token = localStorage.getItem('adminToken');
      if (!token) return;

      const response = await fetch(`http://localhost:5000/api/admin/message/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setMessages(messages.filter((msg) => msg._id !== id));
        setFilteredMessages(filteredMessages.filter((msg) => msg._id !== id));
      } else {
        alert('Failed to delete message');
      }
    } catch (error) {
      console.error('Error deleting message:', error);
    }
  };

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);
    setFilteredMessages(messages.filter((msg) => msg.text.toLowerCase().includes(query)));
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.container}>
        <h2 style={styles.title}>Admin Dashboard</h2>

        {/* Search Bar */}
        <div style={styles.searchContainer}>
          <input
            type="text"
            placeholder="Search messages..."
            value={searchQuery}
            onChange={handleSearch}
            style={styles.searchInput}
          />
          <span style={styles.searchIcon}>🔍</span>
        </div>

        {/* Logout Button */}
        <button onClick={() => navigate('/')} style={styles.logoutButton}>
          Log Out
        </button>

        {/* Messages */}
        <ul style={styles.messageList}>
          {loading
            ? Array.from({ length: 5 }).map((_, index) => (
                <li key={index} style={styles.skeletonLoader}></li>
              ))
            : filteredMessages.length === 0
            ? <p>No messages available</p>
            : filteredMessages.map((msg) => (
                <li key={msg._id} style={styles.messageCard}>
                  <p style={styles.messageText}>{msg.text}</p>
                  <button onClick={() => deleteMessage(msg._id)} style={styles.deleteButton}>
                    🗑 Delete
                  </button>
                </li>
              ))}
        </ul>
      </div>
    </div>
  );
}

// Styles
const styles = {
  pageContainer: {
    width: '100vw',
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: 'linear-gradient(135deg, #2196F3, #E91E63)',
    paddingTop: '10px', // To make space for the fixed header
    overflow: 'auto',
  },
  container: {
    width: '100%',
    maxWidth: '100%',
    padding: '20px',
    background: '#fff',
    borderRadius: '10px',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
    textAlign: 'center',
    overflowY: 'auto',
    maxHeight: '80vh', // Prevents container from getting too tall
  },
  title: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '13px',
  },
  searchContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    right: '15px',
    marginBottom: '20px',
  },
  searchInput: {
    width: '100%',
    padding: '20px',
    borderRadius: '8px',
    border: '1px solid #ccc',
    fontSize: '16px',
    outline: 'none',
    transition: 'border 0.3s',
  },
  searchIcon: {
    position: 'absolute',
    right: '15px',
    fontSize: '18px',
    cursor: 'pointer',
    color: '#777',
  },
  logoutButton: {
    backgroundColor: '#ff5722',
    color: '#fff',
    padding: '10px 20px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    transition: 'background 0.3s',
    marginBottom: '20px',
    position: 'absolute',
    left: '15px',
  },
  messageList: {
    listStyleType: 'none',
    padding: 0,
    marginTop: '70px',
    maxHeight: '60vh',
    overflowY: 'auto',
  },
  messageCard: {
    backgroundColor: '#f1f1f1',
    padding: '15px',
    margin: '10px 0',
    borderRadius: '8px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    transition: 'transform 0.2s, box-shadow 0.2s',
    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
  },
  messageText: {
    fontSize: '16px',
    color: '#444',
    flex: '1',
    wordWrap: 'break-word', // Ensure long words break and wrap
  },
  deleteButton: {
    backgroundColor: '#e91e63',
    color: '#fff',
    padding: '8px 12px',
    borderRadius: '6px',
    border: 'none',
    cursor: 'pointer',
    transition: 'background 0.3s',
  },
  skeletonLoader: {
    width: '100%',
    height: '60px',
    backgroundColor: '#e0e0e0',
    borderRadius: '6px',
    marginTop: '10px',
    animation: 'skeleton 1.5s infinite ease-in-out',
  },
  '@keyframes skeleton': {
    '0%': {
      backgroundColor: '#e0e0e0',
    },
    '50%': {
      backgroundColor: '#ccc',
    },
    '100%': {
      backgroundColor: '#e0e0e0',
    },
  },
  // Media Queries for Responsiveness
  '@media (max-width: 768px)': {
    container: {
      width: '95%',
      padding: '15px',
    },
    searchInput: {
      width: '70%',
    },
    logoutButton: {
      fontSize: '14px',
    },
  },
  '@media (max-width: 480px)': {
    container: {
      width: '100%',
      padding: '10px',
    },
    searchInput: {
      width: '60%',
    },
    title: {
      fontSize: '20px',
    },
    messageCard: {
      padding: '12px',
    },
  },
};

export default AdminDashboard;
