import { useState } from "react";
import MessageForm from "../components/MessageForm";
import MessageList from "../components/MessageList";
import CategoryFilter from "../components/CategoryFilter";
import StoryUploader from "../components/StoryUploader"; // Import the StoryUploader component
import StoryViewer from "../components/StoryViewer"; // Import the StoryViewer component

const Home = () => {
    const [selectedCategory, setSelectedCategory] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isStoryModalOpen, setIsStoryModalOpen] = useState(false); // State for story modal
    const [stories, setStories] = useState([]); // State to store uploaded stories

    const handleCategorySelect = (category) => {
        setSelectedCategory(category);
    };

    const handleStoryUpload = (newStory) => {
        setStories((prevStories) => [...prevStories, newStory]);
    };

    return (
        <div style={styles.container}>
            {/* Clickable Message Modal Button */}
            <div style={styles.modalTrigger} onClick={() => setIsModalOpen(true)}>
                <span style={styles.plusIcon}>+</span>
                <span style={styles.triggerText}>Post a Message</span>
            </div>

            {/* Story Uploader Modal Trigger */}
            <div style={styles.modalTrigger2} onClick={() => setIsStoryModalOpen(true)}>
                <span style={styles.plusIcon}>📸</span>
                <span style={styles.triggerText}>Upload Story</span>
            </div>

            {/* Message Form Modal */}
            {isModalOpen && (
                <div style={styles.modalOverlay} onClick={() => setIsModalOpen(false)}>
                    <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
                        <MessageForm onMessagePosted={() => setIsModalOpen(false)} />
                        <button style={styles.closeButton} onClick={() => setIsModalOpen(false)}>
                            ✖
                        </button>
                    </div>
                </div>
            )}

            {/* Story Uploader Modal */}
            {isStoryModalOpen && (
                <div style={styles.modalOverlay} onClick={() => setIsStoryModalOpen(false)}>
                    <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
                        <StoryUploader onUpload={handleStoryUpload} />
                        <button style={styles.closeButton} onClick={() => setIsStoryModalOpen(false)}>
                            ✖
                        </button>
                    </div>
                </div>
            )}

            <CategoryFilter onSelectCategory={handleCategorySelect} />
            <MessageList selectedCategory={selectedCategory} />

            {/* Story Viewer on the right */}
            <div style={styles.storyViewerContainer}>
                <StoryViewer stories={stories} />
            </div>
        </div>
    );
};

const styles = {
    container: {
        maxWidth: "100%",
        margin: "0 auto",
        padding: "20px",
        backgroundColor: "#f4f4f4",
        borderRadius: "10px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease-in-out",
        paddingTop: "330px", // Adjusted top padding for positioning the modal triggers
        position: "relative",
        display: "flex",
        justifyContent: "space-between", // Align the message and story viewer side by side
        gap: "20px", // Added gap between elements for better spacing
    },

    /** 📌 Modal Trigger for Story Uploader **/
    modalTrigger2: {
        position: "absolute",
        left: "5px",
        top: "69px",
        width: "200px",
        height: "250px",
        background: "linear-gradient(135deg, rgba(0, 123, 255, 0.6), rgba(102, 16, 242, 0.6))",
        borderRadius: "15px",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
        transition: "transform 0.3s ease-in-out",
    },

    /** 📌 Modal Trigger Styles **/
    modalTrigger: {
        position: "fixed",
        right: "10px",
        bottom: "10px", // Adjusted for spacing
        width: "200px",
        height: "70px",
        background: "linear-gradient(135deg, rgba(0, 123, 255, 0.6), rgba(102, 16, 242, 0.6))",
        borderRadius: "15px",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.2)",
        transition: "transform 0.3s ease-in-out",
        overflow: "hidden",
    },

    plusIcon: {
        fontSize: "26px",
        fontWeight: "bold",
        color: "white",
    },
    triggerText: {
        fontSize: "18px",
        color: "white",
        marginTop: "5px",
    },

    /** 📌 Modal Design **/
    modalOverlay: {
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 2000,
        animation: "fadeIn 0.3s ease-in-out",
    },
    modalContent: {
        background: "rgba(255, 255, 255, 0.95)",
        width: "90%",
        maxWidth: "500px",
        padding: "20px",
        borderRadius: "15px",
        boxShadow: "0 6px 20px rgba(0, 0, 0, 0.2)",
        position: "relative",
        textAlign: "center",
        animation: "slideDown 0.4s ease-in-out",
    },
    closeButton: {
        position: "absolute",
        top: "10px",
        right: "10px",
        background: "none",
        border: "none",
        fontSize: "20px",
        cursor: "pointer",
        color: "#333",
    },

    /** 📌 StoryViewer Section **/
    storyViewerContainer: {
        flex: 1,
        Width: "200px", // Ensures the StoryViewer has a minimum width
        overflowX: "auto", // Enables horizontal scroll
        whiteSpace: "nowrap", // Prevents the container from wrapping elements
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "center",
        marginTop: "20px", // Space above the StoryViewer
        position: "absolute",
        left: "210px",
        right: "15px",
        top: "50px",
        height: "250px",
    },

    // Responsive Adjustments
    "@media (max-width: 768px)": {
        container: {
            width: "95%",
            padding: "15px",
            flexDirection: "column", // Stack elements vertically on smaller screens
        },
        storyViewerContainer: {
            marginLeft: 0,
            marginTop: "20px",
            flexDirection: "row", // Make it horizontal when stacked
            justifyContent: "center",
        },
    },
    "@media (max-width: 480px)": {
        container: {
            width: "98%",
            padding: "10px",
        },
        modalTrigger: {
            maxWidth: "300px",
            height: "120px",
        },
        modalTrigger2: {
            maxWidth: "300px",
            height: "120px",
        },
        plusIcon: {
            fontSize: "30px",
        },
        triggerText: {
            fontSize: "16px",
        },
    },
};

// Inject animations into the page
const additionalStyles = `
    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    @keyframes slideDown {
        0% { transform: translateY(-20px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
`;

const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = additionalStyles;
document.head.appendChild(styleSheet);

export default Home;
