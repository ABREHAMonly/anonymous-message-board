import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import MessageList from "../components/MessageList";
import CategoryFilter from "../components/CategoryFilter";

const CategoryPage = () => {
    const { category } = useParams();
    const [selectedCategory, setSelectedCategory] = useState(category);

    useEffect(() => {
        setSelectedCategory(category);
    }, [category]);

    const handleCategorySelect = (newCategory) => {
        setSelectedCategory(newCategory);
    };

    return (
        <div style={styles.container}>
            <h1 style={styles.title}>Category: {selectedCategory}</h1>
            <CategoryFilter onSelectCategory={handleCategorySelect} />
            <MessageList selectedCategory={selectedCategory} />
        </div>
    );
};

const styles = {
    container: {
        maxWidth: "100%",
        margin: "0 auto",
        padding: "20px",
        backgroundColor: "#f4f4f4",
        borderRadius: "10px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease-in-out",
        paddingTop: "80px", // To account for the fixed header height
        position: "relative", // Ensures other content layers don't overlap
    },
    title: {
        fontSize: "28px",
        fontWeight: "bold",
        marginBottom: "20px",
        textAlign: "center",
        color: "#333",
        animation: "fadeIn 0.5s ease-out", // Animation for the title appearance
    },
};

// Optional: Adding fade-in effect for the title using CSS keyframes
const additionalStyles = `
    @keyframes fadeIn {
        0% {
            opacity: 0;
            transform: translateY(-10px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;

export default CategoryPage;
