const Message = require("../models/Message");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Hardcoded admin credentials (for demo purposes)
// Ideally, you should store the admin credentials in the database
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD_HASH = '$2a$10$4thHDu8ISz0bHsauYInNae/Z6kp3lP6HNO74AlTk2D5Bjo7PqfyZy'; // The hashed password for 'admin123'

const JWT_SECRET = process.env.JWT_SECRET; // Use a secure, private key

// Admin login function
const adminLogin = (req, res) => {
  const { username, password } = req.body;

  if (username !== ADMIN_USERNAME) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  // Compare the password hash
  bcrypt.compare(password, ADMIN_PASSWORD_HASH, (err, isMatch) => {
    if (err) {
      return res.status(500).json({ message: 'Server error' });
    }

    if (isMatch) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Generate JWT token if credentials are valid
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });

    return res.status(200).json({ message: 'Login successful', token });
  });
};

// Get all messages (admin only)
const getAllMessages = async (req, res) => {
  try {
    const messages = await Message.find().sort({ createdAt: -1 }); // Get all messages sorted by latest
    res.status(200).json(messages); // Ensure a successful response status
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch messages" });
  }
};

// Delete a message (admin only)
const deleteMessage = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if the message exists before deleting
    const deletedMessage = await Message.findByIdAndDelete(id);

    if (!deletedMessage) {
      return res.status(404).json({ error: "Message not found" });
    }

    res.status(200).json({ message: "Message deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete message" });
  }
};

module.exports = {
  getAllMessages,
  adminLogin,
  deleteMessage
};
