const Message = require("../models/Message");
const checkToxicity = require("../utils/toxicityFilter");

// Get all messages, sorted by latest
const getMessages = async (req, res) => {
    try {
        const messages = await Message.find().sort({ createdAt: -1 });
        res.status(200).json(messages);
    } catch (error) {
        console.error("Error fetching messages:", error);
        res.status(500).json({ error: "Failed to fetch messages. Please try again later." });
    }
};

// Post a new message with AI toxicity filtering
const postMessage = async (req, res) => {
    try {
        const { text, category } = req.body;
        if (!text || !category) {
            return res.status(400).json({ error: "Message and category are required." });
        }

        // Check for toxicity
        const isToxic = await checkToxicity(text);
        if (isToxic) {
            return res.status(400).json({ error: "Your message contains toxic content and cannot be posted." });
        }

        const randomUser = `User${Math.floor(1000 + Math.random() * 9000)}`;
        const newMessage = new Message({ text, category, user: randomUser, upvotes: 0, downvotes: 0 });

        await newMessage.save();
        res.status(201).json({ message: "Message posted successfully!", data: newMessage });
    } catch (error) {
        console.error("Error posting message:", error);
        res.status(500).json({ error: "Failed to post message. Please try again later." });
    }
};

// Upvote or downvote a message
const voteMessage = async (req, res) => {
    try {
        const { id } = req.params;
        const { vote } = req.body; // "upvote" or "downvote"

        const message = await Message.findById(id);
        if (!message) return res.status(404).json({ error: "Message not found." });

        if (vote === "upvote") {
            message.upvotes += 1;
        } else if (vote === "downvote") {
            message.downvotes += 1;
        } else {
            return res.status(400).json({ error: "Invalid vote type. Use 'upvote' or 'downvote'." });
        }

        await message.save();
        res.json({ message: "Vote recorded successfully!", data: message });
    } catch (error) {
        console.error("Error voting on message:", error);
        res.status(500).json({ error: "Vote failed. Please try again later." });
    }
};

module.exports = { getMessages, postMessage, voteMessage };
