const express = require("express");
const { adminLogin, deleteMessage } = require("../controllers/adminController");
const { verifyAdmin } = require("../middleware/authMiddleware");

const router = express.Router();

// Admin login route
router.post("/login", adminLogin);

// Protected route for Admin Dashboard
router.get('/dashboard', verifyAdmin, (req, res) => {
    res.status(200).json({ message: 'Welcome to the Admin Dashboard', admin: req.admin });
});

// Admin deletes a message (protected route)
router.delete("/message/:id", verifyAdmin, deleteMessage);

module.exports = router;
