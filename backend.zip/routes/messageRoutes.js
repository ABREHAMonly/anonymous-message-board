const express = require("express");
const { getMessages, postMessage, voteMessage } = require("../controllers/messageController");

const router = express.Router();

router.get("/", getMessages); // Get all messages
router.post("/", postMessage); // Post a new message
router.patch("/:id/vote", voteMessage); // Upvote or downvote a message

module.exports = router;
